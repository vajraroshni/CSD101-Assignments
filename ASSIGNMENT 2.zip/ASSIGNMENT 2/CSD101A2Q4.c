#include<stdio.h> 
int main()
{
int a,b,c;
printf("Enter first number:");
scanf( "%d", &a );
printf("Enter second number:");
scanf( "%d", &b );
if(b!=0){
c=b/a;
printf("The quotient is %d",c);}
else printf("Cannot divide by zero");

return 0;
}