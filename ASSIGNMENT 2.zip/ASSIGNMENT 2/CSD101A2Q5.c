#include<stdio.h> 
int main()
{
float a,b,c;
printf("Enter first number:");
scanf( "%f", &a );
printf("Enter second number:");
scanf( "%f", &b );
if(b!=0.0){
c=b/a;
printf("The quotient is %f",c);}
else printf("Cannot divide by zero");

return 0;
}